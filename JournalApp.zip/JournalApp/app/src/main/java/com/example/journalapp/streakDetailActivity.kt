package com.example.journalapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity

//class StreakDetailActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContent {
//            // Retrieve the Streak data passed from the intent
//            val streak = intent.getParcelableExtra<Streak>("STREAK_DATA") ?: Streak(0, 0L) // Handle default case
//
//            // Show the details of the streak
//            streakPage()
//        }
//    }
//}