package com.example.journalapp

data class NotesResponse(
    val notes: List<Note>
)
